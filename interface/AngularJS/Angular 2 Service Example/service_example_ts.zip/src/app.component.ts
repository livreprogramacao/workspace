import {Component} from 'angular2/core';
import {CountryService} from './service/country.service'

@Component({
  selector: 'app-component',
  templateUrl: 'src/app.component.tpl.html',
  providers: [CountryService]
})
export class AppComponent {
    constructor(private _countryService: CountryService){
        this._countryService = _countryService;
    }
    
    getCountriesByRegion(){
        this.error = "";
        this.countries = [];
        this._countryService.getCountriesByRegion(this.region)
         .subscribe(
            data => this.countries = data,
            error => this.error = "Region " + this.region + " is invalid."
         );
    }
}